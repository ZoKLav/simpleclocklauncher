#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
./gradlew --no-daemon :app:assembleDebug
printf '\nBuilt APK: app/build/outputs/apk/debug/app-debug.apk\n'
