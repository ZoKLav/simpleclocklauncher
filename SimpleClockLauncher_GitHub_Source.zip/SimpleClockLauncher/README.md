# Simple Clock Launcher

A tiny minimalist Android home launcher with a huge 24-hour clock and a swipe-up app drawer.

Package name / application ID:

```text
com.zoey.simpleclocklauncher
```

## Features

- Android home/launcher app.
- Supports Android 7.0 Nougat and newer, `minSdk 24`.
- Huge 24-hour clock, with hours on top and minutes underneath.
- Clock auto-sizes to fill the screen while keeping roughly 10% margins.
- Swipe up to open an alphabetical app drawer.
- Swipe down or press Back to close the app drawer.
- Small `Made by ZoeyKL` watermark in the lower-left of the app drawer.
- Dark red/black radial gradient with Android wallpaper passthrough.
- No internet permission, ads, analytics, accounts, or tracking.
- Vector/nodpi launcher resources and explicit small-screen support for odd devices such as watches or tiny Android phones.

## Requirements

To build locally, install:

- Android Studio or Android SDK command-line tools.
- Android SDK Platform 35.
- JDK 17. Android Studio normally includes one.

You do **not** need a system-wide Gradle install. The included `gradlew` / `gradlew.bat` script downloads Gradle 8.7 into `.gradle-dist` the first time it runs.

This is a lightweight Gradle runner for source distribution, not the stock Gradle Wrapper JAR layout. Android Studio can also build the project normally.

## Build on Windows

```bat
build.bat
```

The APK will be created here:

```text
app\build\outputs\apk\debug\app-debug.apk
```

## Build on macOS / Linux

```sh
chmod +x gradlew build.sh install.sh
./build.sh
```

The APK will be created here:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Install with ADB

Windows:

```bat
install.bat
```

macOS / Linux:

```sh
./install.sh
```

Or manually:

```sh
adb install -r -d app/build/outputs/apk/debug/app-debug.apk
```

After install, press the device Home button and select **Simple Clock Launcher**. You can change the default later in Android settings under default apps / home app.

## GitHub Actions build

This repo includes `.github/workflows/android-build.yml`. After pushing to GitHub, open the **Actions** tab and run **Android Build**. The built debug APK will appear as an Actions artifact.

## Notes

The app queries launchable activities using the normal launcher intent and uses the Android 11+ package visibility `<queries>` declaration for launcher apps. It does not request `QUERY_ALL_PACKAGES`.

The wallpaper is shown using the window wallpaper flag, then the app draws a translucent dark red/black overlay above it. This avoids storage permissions and works better with live wallpapers.
