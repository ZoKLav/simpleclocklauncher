@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Lightweight project-local Gradle runner for source distributions.
rem It downloads Gradle into .gradle-dist, then runs it. No system Gradle install needed.

set "GRADLE_VERSION=8.7"
set "GRADLE_DIST_TYPE=bin"
set "GRADLE_DIST_DIR=%~dp0.gradle-dist"
set "GRADLE_HOME=%GRADLE_DIST_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%GRADLE_DIST_DIR%\gradle-%GRADLE_VERSION%-%GRADLE_DIST_TYPE%.zip"
set "GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-%GRADLE_DIST_TYPE%.zip"

where java >nul 2>nul
if not %errorlevel%==0 (
    echo Java was not found. Install JDK 17 or open/build through Android Studio.
    exit /b 1
)

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
    echo Gradle %GRADLE_VERSION% was not found locally.
    echo Downloading it once from:
    echo %GRADLE_URL%
    echo.

    if not exist "%GRADLE_DIST_DIR%" mkdir "%GRADLE_DIST_DIR%"
    if exist "%GRADLE_ZIP%" del /q "%GRADLE_ZIP%" >nul 2>nul

    where curl.exe >nul 2>nul
    if %errorlevel%==0 (
        curl.exe -L --fail --output "%GRADLE_ZIP%" "%GRADLE_URL%"
    ) else (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%GRADLE_URL%' -OutFile '%GRADLE_ZIP%'"
    )

    if not exist "%GRADLE_ZIP%" (
        echo Could not download Gradle. Check internet access.
        exit /b 1
    )

    powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_ZIP%' '%GRADLE_DIST_DIR%'"
    if errorlevel 1 (
        echo Could not unzip Gradle. Delete .gradle-dist and try again.
        exit /b 1
    )
)

set "CLASSPATH="
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %errorlevel%
