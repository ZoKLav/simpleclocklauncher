#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
APK="app/build/outputs/apk/debug/app-debug.apk"

if [ ! -f "$APK" ]; then
  ./build.sh
fi

ADB="${ANDROID_HOME:-}/platform-tools/adb"
if [ ! -x "$ADB" ]; then
  ADB="${ANDROID_SDK_ROOT:-}/platform-tools/adb"
fi
if [ ! -x "$ADB" ]; then
  ADB="adb"
fi

"$ADB" install -r -d "$APK"
printf '\nInstalled. Press Home on the Android device and choose Simple Clock Launcher.\n'
