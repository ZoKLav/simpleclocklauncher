@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "APK=app\build\outputs\apk\debug\app-debug.apk"
set "ADB=adb"

if not exist "%APK%" (
    echo Debug APK not found: %APK%
    echo Running build.bat first...
    call "%~dp0build.bat"
    if errorlevel 1 exit /b %errorlevel%
)

where adb >nul 2>nul
if not %errorlevel%==0 (
    if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
    if "%ADB%"=="adb" if defined ANDROID_SDK_ROOT if exist "%ANDROID_SDK_ROOT%\platform-tools\adb.exe" set "ADB=%ANDROID_SDK_ROOT%\platform-tools\adb.exe"
    if "%ADB%"=="adb" if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
)

if "%ADB%"=="adb" (
    where adb >nul 2>nul
    if not %errorlevel%==0 (
        echo adb was not found. Install Android SDK Platform Tools or add adb to PATH.
        pause
        exit /b 1
    )
)

echo Installing %APK% ...
"%ADB%" install -r -d "%APK%"
if not %errorlevel%==0 (
    echo.
    echo adb install failed. Make sure USB debugging is enabled and the device is authorized.
    echo.
    pause
    exit /b 1
)

echo.
echo Installed. Press Home on the Android device and choose Simple Clock Launcher.
echo.
pause
exit /b 0
