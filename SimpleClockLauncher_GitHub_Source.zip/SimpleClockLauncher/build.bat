@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo.
echo Building Simple Clock Launcher debug APK...
echo.

rem If Android Studio has created a local.properties file, Gradle will use it.
rem Otherwise Gradle will use ANDROID_HOME or ANDROID_SDK_ROOT if set.
if not exist "local.properties" (
    if defined ANDROID_HOME if exist "%ANDROID_HOME%\platforms" (
        set "SDK_ESCAPED=%ANDROID_HOME:\=\\%"
        > "%~dp0local.properties" echo sdk.dir=%SDK_ESCAPED%
    ) else if defined ANDROID_SDK_ROOT if exist "%ANDROID_SDK_ROOT%\platforms" (
        set "SDK_ESCAPED=%ANDROID_SDK_ROOT:\=\\%"
        > "%~dp0local.properties" echo sdk.dir=%SDK_ESCAPED%
    ) else if exist "%LOCALAPPDATA%\Android\Sdk\platforms" (
        set "SDK_ESCAPED=%LOCALAPPDATA%\Android\Sdk"
        set "SDK_ESCAPED=%SDK_ESCAPED:\=\\%"
        > "%~dp0local.properties" echo sdk.dir=%SDK_ESCAPED%
    )
)

call "%~dp0gradlew.bat" --no-daemon :app:assembleDebug
set BUILD_RESULT=%errorlevel%

if not "%BUILD_RESULT%"=="0" (
    echo.
    echo Build failed. Scroll up for the Gradle error.
    echo.
    pause
    exit /b %BUILD_RESULT%
)

if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo.
    echo Built successfully:
    echo app\build\outputs\apk\debug\app-debug.apk
    echo.
) else (
    echo.
    echo Gradle finished, but the debug APK was not found where expected.
    echo.
    pause
    exit /b 1
)

pause
exit /b 0
