package com.zoey.simpleclocklauncher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.content.res.Configuration;
import android.util.TypedValue;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private FrameLayout root;
    private FrameLayout drawer;
    private GridLayout appGrid;
    private TextView drawerTitle;
    private TextView appCountView;
    private ClockFaceView clockFaceView;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable clockTick = new Runnable() {
        @Override
        public void run() {
            updateClock();
            scheduleNextMinuteTick();
        }
    };

    private float gestureStartX;
    private float gestureStartY;
    private boolean drawerVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER, WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        buildHomeScreen();
        applyResponsiveSizing();
        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        updateClock();
        scheduleNextMinuteTick();
        loadApps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(clockTick);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(clockTick);
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyResponsiveSizing();
        if (drawerVisible) {
            loadApps();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeDrawer(false);
        hideSystemUi();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUi();
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerVisible) {
            closeDrawer(true);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                gestureStartX = event.getX();
                gestureStartY = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                float dx = event.getX() - gestureStartX;
                float dy = event.getY() - gestureStartY;
                int threshold = dp(72);
                boolean mostlyVertical = Math.abs(dy) > Math.abs(dx) * 1.25f;
                if (!drawerVisible && mostlyVertical && dy < -threshold) {
                    openDrawer(true);
                    return true;
                }
                if (drawerVisible && mostlyVertical && dy > threshold) {
                    closeDrawer(true);
                    return true;
                }
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    private void buildHomeScreen() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        setContentView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        root.addView(new GradientOverlayView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        clockFaceView = new ClockFaceView(this);
        root.addView(clockFaceView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        TextView hint = new TextView(this);
        hint.setText("swipe up");
        hint.setTextColor(Color.argb(130, 238, 220, 224));
        hint.setTextSize(12);
        hint.setGravity(Gravity.CENTER);
        hint.setAllCaps(true);
        hint.setLetterSpacing(0.18f);
        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
        );
        hintParams.setMargins(0, 0, 0, dp(28));
        root.addView(hint, hintParams);

        buildDrawer();
    }


    private void applyResponsiveSizing() {
        if (clockFaceView != null) {
            clockFaceView.invalidate();
        }
    }

    private void buildDrawer() {
        drawer = new FrameLayout(this);
        drawer.setVisibility(View.GONE);
        drawer.setClickable(true);
        drawer.setFocusable(true);
        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        drawer.addView(new DrawerBackgroundView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER_HORIZONTAL);
        header.setPadding(dp(20), dp(28), dp(20), dp(10));

        drawerTitle = new TextView(this);
        drawerTitle.setText("Apps");
        drawerTitle.setTextColor(Color.rgb(250, 232, 236));
        drawerTitle.setTextSize(22);
        drawerTitle.setGravity(Gravity.CENTER);
        drawerTitle.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));

        appCountView = new TextView(this);
        appCountView.setTextColor(Color.argb(145, 238, 220, 224));
        appCountView.setTextSize(12);
        appCountView.setGravity(Gravity.CENTER);
        appCountView.setAllCaps(true);
        appCountView.setLetterSpacing(0.12f);

        header.addView(drawerTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        header.addView(appCountView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        drawer.addView(header, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
        ));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        scrollView.setClipToPadding(false);
        scrollView.setPadding(0, dp(96), 0, dp(46));

        appGrid = new GridLayout(this);
        appGrid.setUseDefaultMargins(false);
        appGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        appGrid.setPadding(dp(10), dp(10), dp(10), dp(28));
        scrollView.addView(appGrid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        drawer.addView(scrollView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        TextView watermark = new TextView(this);
        watermark.setText("Made by ZoeyKL");
        watermark.setTextColor(Color.argb(120, 238, 220, 224));
        watermark.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        watermark.setGravity(Gravity.LEFT);
        watermark.setIncludeFontPadding(false);
        FrameLayout.LayoutParams watermarkParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.LEFT
        );
        watermarkParams.setMargins(dp(12), 0, 0, dp(9));
        drawer.addView(watermark, watermarkParams);
    }

    private void updateClock() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        String hourText = String.format(Locale.US, "%02d", hour);
        String minuteText = String.format(Locale.US, "%02d", minute);
        if (clockFaceView != null) {
            clockFaceView.setTime(hourText, minuteText);
        }
    }

    private void scheduleNextMinuteTick() {
        handler.removeCallbacks(clockTick);
        long now = System.currentTimeMillis();
        long delay = 60000L - (now % 60000L) + 100L;
        handler.postDelayed(clockTick, delay);
    }

    private void openDrawer(boolean animate) {
        if (drawerVisible) return;
        drawerVisible = true;
        drawer.setVisibility(View.VISIBLE);
        drawer.bringToFront();
        hideSystemUi();
        if (animate) {
            drawer.setAlpha(0f);
            drawer.setTranslationY(dp(42));
            drawer.animate().alpha(1f).translationY(0f).setDuration(180L).start();
        } else {
            drawer.setAlpha(1f);
            drawer.setTranslationY(0f);
        }
    }

    private void closeDrawer(boolean animate) {
        if (!drawerVisible && drawer.getVisibility() != View.VISIBLE) return;
        drawerVisible = false;
        hideSystemUi();
        if (animate) {
            drawer.animate()
                    .alpha(0f)
                    .translationY(dp(42))
                    .setDuration(150L)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            drawer.setVisibility(View.GONE);
                            drawer.setAlpha(1f);
                            drawer.setTranslationY(0f);
                        }
                    }).start();
        } else {
            drawer.animate().cancel();
            drawer.setVisibility(View.GONE);
            drawer.setAlpha(1f);
            drawer.setTranslationY(0f);
        }
    }

    private void loadApps() {
        final PackageManager packageManager = getPackageManager();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Intent queryIntent = new Intent(Intent.ACTION_MAIN, null);
                queryIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(queryIntent, 0);
                final List<AppEntry> apps = new ArrayList<>();

                for (ResolveInfo resolveInfo : resolveInfos) {
                    ActivityInfo activityInfo = resolveInfo.activityInfo;
                    if (activityInfo == null) continue;
                    if (getPackageName().equals(activityInfo.packageName)) continue;

                    CharSequence label = resolveInfo.loadLabel(packageManager);
                    Drawable icon = resolveInfo.loadIcon(packageManager);
                    Intent launchIntent = new Intent(Intent.ACTION_MAIN);
                    launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                    launchIntent.setComponent(new ComponentName(activityInfo.packageName, activityInfo.name));
                    launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

                    apps.add(new AppEntry(
                            label == null ? activityInfo.packageName : label.toString(),
                            icon,
                            launchIntent,
                            activityInfo.packageName
                    ));
                }

                final Collator collator = Collator.getInstance(Locale.getDefault());
                Collections.sort(apps, (a, b) -> collator.compare(a.label, b.label));

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        populateAppGrid(apps);
                    }
                });
            }
        }, "AppLoader").start();
    }

    private void populateAppGrid(List<AppEntry> apps) {
        appGrid.removeAllViews();

        int width = getResources().getDisplayMetrics().widthPixels;
        float density = Math.max(1f, getResources().getDisplayMetrics().density);
        float widthDp = width / density;
        int minCellWidth = dp(widthDp < 260f ? 70 : 88);
        int columns = Math.max(1, width / Math.max(1, minCellWidth));
        if (widthDp >= 320f) columns = Math.max(3, columns);
        if (widthDp >= 520f) columns = Math.max(5, columns);
        appGrid.setColumnCount(columns);
        int cellWidth = Math.max(1, width / columns);
        int iconSize = Math.max(dp(32), Math.min(dp(48), cellWidth - dp(22)));
        int cellHeight = Math.max(dp(86), Math.min(dp(112), iconSize + dp(58)));

        appCountView.setText(apps.size() + " installed apps");

        if (apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No launchable apps found");
            empty.setTextColor(Color.rgb(245, 232, 235));
            empty.setGravity(Gravity.CENTER);
            empty.setTextSize(16);
            appGrid.addView(empty, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(120)
            ));
            return;
        }

        for (final AppEntry app : apps) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(6), dp(10), dp(6), dp(6));
            cell.setClickable(true);
            cell.setFocusable(true);
            cell.setBackground(makeSelectableBackground());
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        startActivity(app.launchIntent);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Could not open " + app.label, Toast.LENGTH_SHORT).show();
                    }
                }
            });

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(app.icon);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(iconSize, iconSize);
            iconParams.gravity = Gravity.CENTER_HORIZONTAL;
            cell.addView(icon, iconParams);

            TextView label = new TextView(this);
            label.setText(app.label);
            label.setTextColor(Color.rgb(242, 226, 230));
            label.setTextSize(11);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setIncludeFontPadding(true);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            labelParams.setMargins(0, dp(7), 0, 0);
            cell.addView(label, labelParams);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = cellWidth;
            params.height = cellHeight;
            params.setMargins(0, 0, 0, dp(2));
            appGrid.addView(cell, params);
        }
    }

    private Drawable makeSelectableBackground() {
        android.graphics.drawable.StateListDrawable states = new android.graphics.drawable.StateListDrawable();
        android.graphics.drawable.GradientDrawable pressed = new android.graphics.drawable.GradientDrawable();
        pressed.setColor(Color.argb(70, 145, 0, 28));
        pressed.setCornerRadius(dp(14));
        android.graphics.drawable.GradientDrawable normal = new android.graphics.drawable.GradientDrawable();
        normal.setColor(Color.TRANSPARENT);
        normal.setCornerRadius(dp(14));
        states.addState(new int[]{android.R.attr.state_pressed}, pressed);
        states.addState(new int[]{android.R.attr.state_focused}, pressed);
        states.addState(new int[]{}, normal);
        return states;
    }

    private void hideSystemUi() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class AppEntry {
        final String label;
        final Drawable icon;
        final Intent launchIntent;
        final String packageName;

        AppEntry(String label, Drawable icon, Intent launchIntent, String packageName) {
            this.label = label;
            this.icon = icon;
            this.launchIntent = launchIntent;
            this.packageName = packageName;
        }
    }


    private static class ClockFaceView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private String hour = "00";
        private String minute = "00";
        private float cachedTextSize = -1f;
        private int cachedWidth = -1;
        private int cachedHeight = -1;

        ClockFaceView(android.content.Context context) {
            super(context);
            setWillNotDraw(false);
            paint.setColor(Color.rgb(245, 232, 235));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            paint.setShadowLayer(18f, 0f, 4f, Color.argb(185, 70, 0, 10));
        }

        void setTime(String hour, String minute) {
            if (!this.hour.equals(hour) || !this.minute.equals(minute)) {
                this.hour = hour;
                this.minute = minute;
                invalidate();
            }
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            cachedTextSize = -1f;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int width = getWidth();
            int height = getHeight();
            if (width <= 0 || height <= 0) return;

            float marginX = width * 0.10f;
            float marginY = height * 0.10f;
            float availableWidth = Math.max(1f, width - marginX * 2f);
            float availableHeight = Math.max(1f, height - marginY * 2f);

            if (cachedTextSize <= 0f || cachedWidth != width || cachedHeight != height) {
                cachedWidth = width;
                cachedHeight = height;
                cachedTextSize = findBestClockTextSize(availableWidth, availableHeight);
            }

            paint.setTextSize(cachedTextSize);
            Paint.FontMetrics metrics = paint.getFontMetrics();
            float lineHeight = metrics.descent - metrics.ascent;
            float gap = cachedTextSize * 0.04f;
            float totalHeight = lineHeight * 2f + gap;
            float top = marginY + (availableHeight - totalHeight) / 2f;
            float baselineHour = top - metrics.ascent;
            float baselineMinute = baselineHour + lineHeight + gap;
            float centerX = width * 0.5f;

            canvas.drawText(hour, centerX, baselineHour, paint);
            canvas.drawText(minute, centerX, baselineMinute, paint);
        }

        private float findBestClockTextSize(float availableWidth, float availableHeight) {
            float low = 8f;
            float high = Math.max(12f, Math.min(availableWidth, availableHeight) * 1.25f);
            for (int i = 0; i < 28; i++) {
                float mid = (low + high) * 0.5f;
                paint.setTextSize(mid);
                Paint.FontMetrics metrics = paint.getFontMetrics();
                float lineHeight = metrics.descent - metrics.ascent;
                float gap = mid * 0.04f;
                float totalHeight = lineHeight * 2f + gap;
                float textWidth = Math.max(paint.measureText("88"), Math.max(paint.measureText(hour), paint.measureText(minute)));
                if (textWidth <= availableWidth && totalHeight <= availableHeight) {
                    low = mid;
                } else {
                    high = mid;
                }
            }
            return low;
        }
    }

    private static class GradientOverlayView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int lastWidth = -1;
        private int lastHeight = -1;

        GradientOverlayView(android.content.Context context) {
            super(context);
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int width = getWidth();
            int height = getHeight();
            if (width <= 0 || height <= 0) return;

            if (width != lastWidth || height != lastHeight || paint.getShader() == null) {
                lastWidth = width;
                lastHeight = height;
                float radius = Math.max(width, height) * 0.82f;
                paint.setShader(new RadialGradient(
                        width * 0.5f,
                        height * 0.38f,
                        radius,
                        new int[]{
                                Color.argb(168, 82, 0, 16),
                                Color.argb(222, 18, 0, 3),
                                Color.argb(246, 0, 0, 0)
                        },
                        new float[]{0.0f, 0.55f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
            }
            canvas.drawRect(0, 0, width, height, paint);
        }
    }

    private static class DrawerBackgroundView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint topPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int lastWidth = -1;
        private int lastHeight = -1;

        DrawerBackgroundView(android.content.Context context) {
            super(context);
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int width = getWidth();
            int height = getHeight();
            if (width <= 0 || height <= 0) return;

            if (width != lastWidth || height != lastHeight || paint.getShader() == null) {
                lastWidth = width;
                lastHeight = height;
                paint.setShader(new RadialGradient(
                        width * 0.5f,
                        height * 0.12f,
                        Math.max(width, height) * 0.85f,
                        new int[]{
                                Color.argb(242, 74, 0, 15),
                                Color.argb(248, 10, 0, 2),
                                Color.argb(252, 0, 0, 0)
                        },
                        new float[]{0.0f, 0.50f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                topPaint.setShader(new LinearGradient(
                        0, 0, 0, Math.max(1, height * 0.30f),
                        Color.argb(210, 0, 0, 0),
                        Color.argb(0, 0, 0, 0),
                        Shader.TileMode.CLAMP
                ));
            }
            canvas.drawRect(0, 0, width, height, paint);
            canvas.drawRect(0, 0, width, height * 0.35f, topPaint);
        }
    }
}
